$ErrorActionPreference = 'Stop'
$Source = Split-Path -Parent $MyInvocation.MyCommand.Path
$Base = Join-Path $env:LOCALAPPDATA 'MindsparkBot'
$LauncherDir = Join-Path $Base 'launcher'
New-Item -ItemType Directory -Force -Path $LauncherDir | Out-Null

function Find-Python {
    $py = Get-Command py.exe -ErrorAction SilentlyContinue
    if ($py) { return @($py.Source, '-3') }
    $python = Get-Command python.exe -ErrorAction SilentlyContinue
    if ($python) { return @($python.Source) }
    return $null
}

# Keep even a single python.exe result as an array so $Python[0] is
# the full executable path, rather than its first character (for example C).
$Python = @(Find-Python)
if (-not $Python) {
    $winget = Get-Command winget.exe -ErrorAction SilentlyContinue
    if (-not $winget) {
        Add-Type -AssemblyName PresentationFramework
        [System.Windows.MessageBox]::Show(
            'Python is not installed and Windows Package Manager was not found. Install Python 3, then run this installer again.',
            'MAACC Bot') | Out-Null
        exit 1
    }
    Write-Host 'Installing Python automatically...'
    & winget install --id Python.Python.3.12 --exact --silent --accept-package-agreements --accept-source-agreements
    $env:Path = [Environment]::GetEnvironmentVariable('Path','Machine') + ';' +
                [Environment]::GetEnvironmentVariable('Path','User')
    $Python = @(Find-Python)
    if (-not $Python) {
        throw 'Python installation finished but Python could not be located. Restart Windows and run this installer again.'
    }
}

Copy-Item -Force (Join-Path $Source 'launcher.py') (Join-Path $LauncherDir 'launcher.py')
Copy-Item -Force (Join-Path $Source 'seed_update.msupdate') (Join-Path $LauncherDir 'seed_update.msupdate')
Copy-Item -Force (Join-Path $Source 'mindspark_bot.ico') (Join-Path $LauncherDir 'mindspark_bot.ico')

$ConfigPath = Join-Path $Base 'update_config.json'
$UpdateConfig = @{
    manifest_url = 'https://raw.githubusercontent.com/Noodlee-4767/Windows-MAACC-Updates/main/Windows-latest.json'
    auto_check = $true
}
$ConfigJson = $UpdateConfig | ConvertTo-Json
[System.IO.File]::WriteAllText(
    $ConfigPath, $ConfigJson, (New-Object System.Text.UTF8Encoding($false)))

$VbsLaunch = @'
Set sh = CreateObject("WScript.Shell")
base = sh.ExpandEnvironmentStrings("%LOCALAPPDATA%") & "\MindsparkBot"
pyw = base & "\runtime\Scripts\pythonw.exe"
launcher = base & "\launcher\launcher.py"
If CreateObject("Scripting.FileSystemObject").FileExists(pyw) Then
  sh.Run Chr(34) & pyw & Chr(34) & " " & Chr(34) & launcher & Chr(34) & " --launch", 0, False
Else
  sh.Run "pyw.exe " & Chr(34) & launcher & Chr(34) & " --launch", 0, False
End If
'@
$VbsUpdate = @'
Set sh = CreateObject("WScript.Shell")
base = sh.ExpandEnvironmentStrings("%LOCALAPPDATA%") & "\MindsparkBot"
pyw = base & "\runtime\Scripts\pythonw.exe"
launcher = base & "\launcher\launcher.py"
If CreateObject("Scripting.FileSystemObject").FileExists(pyw) Then
  sh.Run Chr(34) & pyw & Chr(34) & " " & Chr(34) & launcher & Chr(34) & " --updater", 0, False
Else
  sh.Run "pyw.exe " & Chr(34) & launcher & Chr(34) & " --updater", 0, False
End If
'@
Set-Content -Encoding ASCII -Path (Join-Path $LauncherDir 'launch.vbs') -Value $VbsLaunch
Set-Content -Encoding ASCII -Path (Join-Path $LauncherDir 'updater.vbs') -Value $VbsUpdate

$Exe = $Python[0]
$Extra = @()
if ($Python.Count -gt 1) { $Extra = $Python[1..($Python.Count-1)] }
& $Exe @Extra (Join-Path $LauncherDir 'launcher.py') --install-seed
if ($LASTEXITCODE -ne 0) { throw 'Could not install the packaged MAACC Bot version.' }
& $Exe @Extra (Join-Path $LauncherDir 'launcher.py') --prepare-runtime
if ($LASTEXITCODE -ne 0) { throw 'Could not prepare the private MAACC Bot runtime.' }

$WshShell = New-Object -ComObject WScript.Shell
$Desktop = [Environment]::GetFolderPath('Desktop')
$StartMenu = Join-Path $env:APPDATA 'Microsoft\Windows\Start Menu\Programs'
$Icon = Join-Path $LauncherDir 'mindspark_bot.ico'

$Shortcut = $WshShell.CreateShortcut((Join-Path $Desktop 'Mindspark Bot.lnk'))
$Shortcut.TargetPath = "$env:WINDIR\System32\wscript.exe"
$Shortcut.Arguments = '"' + (Join-Path $LauncherDir 'launch.vbs') + '"'
$Shortcut.WorkingDirectory = $Base
$Shortcut.Description = 'MAACC Mindspark Bot'
$Shortcut.IconLocation = $Icon
$Shortcut.Save()

$Shortcut2 = $WshShell.CreateShortcut((Join-Path $StartMenu 'Mindspark Bot.lnk'))
$Shortcut2.TargetPath = "$env:WINDIR\System32\wscript.exe"
$Shortcut2.Arguments = '"' + (Join-Path $LauncherDir 'launch.vbs') + '"'
$Shortcut2.WorkingDirectory = $Base
$Shortcut2.Description = 'MAACC Mindspark Bot'
$Shortcut2.IconLocation = $Icon
$Shortcut2.Save()

$Shortcut3 = $WshShell.CreateShortcut((Join-Path $StartMenu 'Mindspark Bot Updater.lnk'))
$Shortcut3.TargetPath = "$env:WINDIR\System32\wscript.exe"
$Shortcut3.Arguments = '"' + (Join-Path $LauncherDir 'updater.vbs') + '"'
$Shortcut3.WorkingDirectory = $Base
$Shortcut3.Description = 'Update or restore MAACC Mindspark Bot'
$Shortcut3.IconLocation = $Icon
$Shortcut3.Save()

Add-Type -AssemblyName PresentationFramework
[System.Windows.MessageBox]::Show(
    "MAACC Bot v1.1.41 is installed.`n`nThe Windows Python-path correction, queue wraparound fix, hard-limit closure, and in-app Uninstall button are included.",
    'MAACC Bot') | Out-Null
