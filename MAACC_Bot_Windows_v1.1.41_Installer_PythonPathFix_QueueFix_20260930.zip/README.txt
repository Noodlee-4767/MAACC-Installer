MAACC MINDSPARK BOT — WINDOWS INSTALLER v1.1.41 — Python path fix (2026-09-30)

1. Extract this ZIP completely.
2. Double-click INSTALL_MAACC_BOT.cmd.
3. Wait for setup to finish, then open “Mindspark Bot”.

If the previous setup failed with "The term C is not recognized",
simply run this corrected installer. You do not need to uninstall first.
The correction handles both python.exe and the py.exe launcher.

This installer includes:
- The current Windows v1.1.41 bot.
- The Windows-only update channel (Windows-latest.json).
- Full Auto Stop closes all browser tabs opened by the bot.
- An UNINSTALL button inside the bot. It asks:
  “Do you want to uninstall the MAACC bot ?”
  Nothing is removed unless you choose Yes.

Keep every extracted installer file together while installing.
