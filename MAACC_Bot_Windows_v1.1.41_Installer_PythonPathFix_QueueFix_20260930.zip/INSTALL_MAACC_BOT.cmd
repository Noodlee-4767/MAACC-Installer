@echo off
setlocal
title MAACC Bot Installer
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0install.ps1"
if errorlevel 1 (
  echo.
  echo Installation did not finish. Read the message above, then try again.
  pause
)
endlocal
