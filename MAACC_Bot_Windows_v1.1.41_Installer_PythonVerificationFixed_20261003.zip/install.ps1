$ErrorActionPreference = 'Stop'
$Source = Split-Path -Parent $MyInvocation.MyCommand.Path
$Base = Join-Path $env:LOCALAPPDATA 'MindsparkBot'
$LauncherDir = Join-Path $Base 'launcher'
New-Item -ItemType Directory -Force -Path $LauncherDir | Out-Null
$PythonCheckLog = Join-Path $Base 'installer-python-check.log'
try { Start-Transcript -Path (Join-Path $Base 'installer.log') -Force | Out-Null } catch { }

function Write-PythonCheckLog {
    param([string]$Message)
    try {
        [System.IO.File]::AppendAllText(
            $PythonCheckLog, ([DateTime]::Now.ToString('s') + ' ' + $Message + [Environment]::NewLine))
    } catch { }
}

function Test-Python {
    param([string]$Executable, [string[]]$Arguments = @())
    if (-not $Executable) { return $false }
    # Windows PowerShell 5.1 strips embedded double quotes in native arguments.
    # Use single quotes inside Python code so the marker remains a string.
    $ProbeCode = "import sys, venv, ensurepip, tkinter; assert sys.version_info >= (3, 10); print('__MAACC_PYTHON_OK__')"
    $SavedPreference = $ErrorActionPreference
    try {
        # Capture diagnostics without a native stderr record aborting discovery.
        $ErrorActionPreference = 'Continue'
        $Probe = @(& $Executable @Arguments -I -c $ProbeCode 2>&1)
        $ProbeExitCode = $LASTEXITCODE
        if ($ProbeExitCode -eq 0 -and $Probe -contains '__MAACC_PYTHON_OK__') {
            Write-PythonCheckLog ('Verified: ' + $Executable)
            return $true
        }
        Write-PythonCheckLog ('Rejected: ' + $Executable + '; exit=' + $ProbeExitCode + '; output=' + ($Probe | Out-String))
    } catch {
        Write-PythonCheckLog ('Rejected: ' + $Executable + '; error=' + $_.Exception.Message)
    } finally {
        $ErrorActionPreference = $SavedPreference
    }
    return $false
}

function Find-Python {
    $PrivatePython = Join-Path $Base 'runtime\Scripts\python.exe'
    if ((Test-Path -LiteralPath $PrivatePython -PathType Leaf) -and
        (Test-Python -Executable $PrivatePython)) {
        return @($PrivatePython)
    }

    foreach ($CommandName in @('py.exe', 'python.exe', 'python3.exe')) {
        foreach ($Command in @(Get-Command $CommandName -CommandType Application -All -ErrorAction SilentlyContinue)) {
            # Do not execute the Microsoft Store redirect aliases.
            if ($Command.Source -like (Join-Path $env:LOCALAPPDATA 'Microsoft\WindowsApps\*')) { continue }
            $Arguments = @()
            if ($CommandName -eq 'py.exe') { $Arguments = @('-3') }
            if (Test-Python -Executable $Command.Source -Arguments $Arguments) {
                return @($Command.Source) + $Arguments
            }
        }
    }

    # An existing installation may not be on this process's PATH yet.
    $Candidates = @()
    foreach ($RegistryRoot in @(
        'HKCU:\Software\Python\PythonCore',
        'HKLM:\Software\Python\PythonCore',
        'HKLM:\Software\WOW6432Node\Python\PythonCore'
    )) {
        foreach ($VersionKey in @(Get-ChildItem -LiteralPath $RegistryRoot -ErrorAction SilentlyContinue)) {
            try {
                $InstallKey = Get-Item -LiteralPath (Join-Path $VersionKey.PSPath 'InstallPath') -ErrorAction Stop
                $RegisteredExe = [string]$InstallKey.GetValue('ExecutablePath')
                if ($RegisteredExe) { $Candidates += $RegisteredExe }
                $InstallDir = [string]$InstallKey.GetValue('')
                if ($InstallDir) { $Candidates += Join-Path $InstallDir 'python.exe' }
            } catch { }
        }
    }
    foreach ($ParentDir in @(
        (Join-Path $env:LOCALAPPDATA 'Programs\Python'),
        $env:ProgramFiles,
        ${env:ProgramFiles(x86)},
        $env:SystemDrive
    )) {
        if (-not $ParentDir) { continue }
        foreach ($Directory in @(Get-ChildItem -LiteralPath $ParentDir -Directory -Filter 'Python*' -ErrorAction SilentlyContinue | Sort-Object Name -Descending)) {
            $Candidates += Join-Path $Directory.FullName 'python.exe'
        }
    }
    foreach ($Candidate in @($Candidates | Select-Object -Unique)) {
        if ((Test-Path -LiteralPath $Candidate -PathType Leaf) -and
            (Test-Python -Executable $Candidate)) {
            return @($Candidate)
        }
    }
    return $null
}

# Always capture an array: a single path must never turn into its first character.
$Python = @(Find-Python)
if (-not $Python) {
    $Winget = Get-Command winget.exe -CommandType Application -ErrorAction SilentlyContinue
    if (-not $Winget) {
        throw 'No working Python 3.10+ was found, and Windows Package Manager is unavailable. Install Python from https://www.python.org/downloads/windows/ with pip and Tcl/Tk selected, then run this installer again.'
    }
    Write-Host 'No working Python found. Installing Python automatically...'
    & $Winget.Source install --id Python.Python.3.12 --exact --source winget --scope user --silent --accept-package-agreements --accept-source-agreements
    $PythonInstallExitCode = $LASTEXITCODE
    $OriginalPath = $env:Path
    $env:Path = [Environment]::GetEnvironmentVariable('Path','Machine') + ';' +
                [Environment]::GetEnvironmentVariable('Path','User') + ';' + $OriginalPath
    $Python = @(Find-Python)
    if (-not $Python) {
        throw "A working Python could not be found after automatic setup (winget exit code: $PythonInstallExitCode). Install or repair Python from https://www.python.org/downloads/windows/ with pip and Tcl/Tk selected, then run this installer again."
    }
}
Write-Host ('Using verified Python: ' + $Python[0])


Copy-Item -Force (Join-Path $Source 'launcher.py') (Join-Path $LauncherDir 'launcher.py')
Copy-Item -Force (Join-Path $Source 'seed_update.msupdate') (Join-Path $LauncherDir 'seed_update.msupdate')
Copy-Item -Force (Join-Path $Source 'mindspark_bot.ico') (Join-Path $LauncherDir 'mindspark_bot.ico')

$ConfigPath = Join-Path $Base 'update_config.json'
$UpdateConfig = @{
    manifest_url = 'https://raw.githubusercontent.com/Noodlee-4767/Windows-MAACC-Updates/main/Windows-latest.json'
    auto_check = $true
}
$ConfigJson = $UpdateConfig | ConvertTo-Json
[System.IO.File]::WriteAllText(
    $ConfigPath, $ConfigJson, (New-Object System.Text.UTF8Encoding($false)))

$VbsLaunch = @'
Set sh = CreateObject("WScript.Shell")
base = sh.ExpandEnvironmentStrings("%LOCALAPPDATA%") & "\MindsparkBot"
pyw = base & "\runtime\Scripts\pythonw.exe"
launcher = base & "\launcher\launcher.py"
If CreateObject("Scripting.FileSystemObject").FileExists(pyw) Then
  sh.Run Chr(34) & pyw & Chr(34) & " " & Chr(34) & launcher & Chr(34) & " --launch", 0, False
Else
  sh.Run "pyw.exe " & Chr(34) & launcher & Chr(34) & " --launch", 0, False
End If
'@
$VbsUpdate = @'
Set sh = CreateObject("WScript.Shell")
base = sh.ExpandEnvironmentStrings("%LOCALAPPDATA%") & "\MindsparkBot"
pyw = base & "\runtime\Scripts\pythonw.exe"
launcher = base & "\launcher\launcher.py"
If CreateObject("Scripting.FileSystemObject").FileExists(pyw) Then
  sh.Run Chr(34) & pyw & Chr(34) & " " & Chr(34) & launcher & Chr(34) & " --updater", 0, False
Else
  sh.Run "pyw.exe " & Chr(34) & launcher & Chr(34) & " --updater", 0, False
End If
'@
Set-Content -Encoding ASCII -Path (Join-Path $LauncherDir 'launch.vbs') -Value $VbsLaunch
Set-Content -Encoding ASCII -Path (Join-Path $LauncherDir 'updater.vbs') -Value $VbsUpdate

$Exe = $Python[0]
$Extra = @()
if ($Python.Count -gt 1) { $Extra = $Python[1..($Python.Count-1)] }
& $Exe @Extra (Join-Path $LauncherDir 'launcher.py') --install-seed
if ($LASTEXITCODE -ne 0) { throw 'Could not install the packaged MAACC Bot version.' }
& $Exe @Extra (Join-Path $LauncherDir 'launcher.py') --prepare-runtime
if ($LASTEXITCODE -ne 0) { throw 'Could not prepare the private MAACC Bot runtime.' }

$WshShell = New-Object -ComObject WScript.Shell
$Desktop = [Environment]::GetFolderPath('Desktop')
$StartMenu = Join-Path $env:APPDATA 'Microsoft\Windows\Start Menu\Programs'
$Icon = Join-Path $LauncherDir 'mindspark_bot.ico'

$Shortcut = $WshShell.CreateShortcut((Join-Path $Desktop 'Mindspark Bot.lnk'))
$Shortcut.TargetPath = "$env:WINDIR\System32\wscript.exe"
$Shortcut.Arguments = '"' + (Join-Path $LauncherDir 'launch.vbs') + '"'
$Shortcut.WorkingDirectory = $Base
$Shortcut.Description = 'MAACC Mindspark Bot'
$Shortcut.IconLocation = $Icon
$Shortcut.Save()

$Shortcut2 = $WshShell.CreateShortcut((Join-Path $StartMenu 'Mindspark Bot.lnk'))
$Shortcut2.TargetPath = "$env:WINDIR\System32\wscript.exe"
$Shortcut2.Arguments = '"' + (Join-Path $LauncherDir 'launch.vbs') + '"'
$Shortcut2.WorkingDirectory = $Base
$Shortcut2.Description = 'MAACC Mindspark Bot'
$Shortcut2.IconLocation = $Icon
$Shortcut2.Save()

$Shortcut3 = $WshShell.CreateShortcut((Join-Path $StartMenu 'Mindspark Bot Updater.lnk'))
$Shortcut3.TargetPath = "$env:WINDIR\System32\wscript.exe"
$Shortcut3.Arguments = '"' + (Join-Path $LauncherDir 'updater.vbs') + '"'
$Shortcut3.WorkingDirectory = $Base
$Shortcut3.Description = 'Update or restore MAACC Mindspark Bot'
$Shortcut3.IconLocation = $Icon
$Shortcut3.Save()

Add-Type -AssemblyName PresentationFramework
[System.Windows.MessageBox]::Show(
    "MAACC Bot v1.1.41 is installed.`n`nThe Windows Python-path correction, queue wraparound fix, hard-limit closure, and in-app Uninstall button are included.",
    'MAACC Bot') | Out-Null
try { Stop-Transcript | Out-Null } catch { }
