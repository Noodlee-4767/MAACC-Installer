MAACC MINDSPARK BOT - WINDOWS INSTALLER v1.1.41
Python Store-alias detection fix - 2026-09-30

1. Extract this ZIP completely into a new folder.
2. Double-click INSTALL_MAACC_BOT.cmd.
3. Keep internet connected and wait for setup to finish.
4. Open Mindspark Bot using its desktop or Start Menu shortcut.

You do not need to uninstall after the previous failed setup.

Setup now verifies that Python actually runs before using it. It rejects
nonworking Microsoft Store shortcuts, checks installed Python locations,
and installs Python automatically with Windows Package Manager if needed.
Python must include pip and Tcl/Tk (the normal installer defaults).

If automatic Python setup is unavailable or fails, install Python from:
https://www.python.org/downloads/windows/
Choose pip and Tcl/Tk, then run INSTALL_MAACC_BOT.cmd again.

Setup creates a private environment and installs Playwright, openpyxl,
Pillow and requests automatically. Internet access is required.

The included v1.1.41 bot and launcher are preserved from your supplied ZIP,
including its queue and hard-limit changes, in-app Uninstall button,
Full Auto Stop tab closure and Windows-latest.json update channel.

Keep every extracted installer file together while installing.
