$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[System.Windows.Forms.Application]::EnableVisualStyles()

$source = Split-Path -Parent $MyInvocation.MyCommand.Path
$runner = Join-Path $source 'run-install.ps1'
$logPath = Join-Path $env:TEMP ('mindspark-bot-setup-' + [Diagnostics.Process]::GetCurrentProcess().Id + '.log')
$bg = [System.Drawing.Color]::FromArgb(13,15,20)
$panel = [System.Drawing.Color]::FromArgb(23,28,39)
$text = [System.Drawing.Color]::FromArgb(232,236,243)
$muted = [System.Drawing.Color]::FromArgb(154,165,181)
$green = [System.Drawing.Color]::FromArgb(57,255,136)

function Label($value,$x,$y,$w,$h,$size,$color,$bold=$false) {
    $control = New-Object System.Windows.Forms.Label
    $control.Text = $value; $control.Left=$x; $control.Top=$y
    $control.Width=$w; $control.Height=$h; $control.ForeColor=$color
    $style = if($bold){[System.Drawing.FontStyle]::Bold}else{[System.Drawing.FontStyle]::Regular}
    $control.Font = [System.Drawing.Font]::new('Segoe UI',[single]$size,$style)
    $control.BackColor=$bg
    return $control
}

$form=New-Object System.Windows.Forms.Form
$form.Text='Mindspark Bot Setup'
$form.Size=[System.Drawing.Size]::new(690,560)
$form.MinimumSize=$form.Size; $form.MaximumSize=$form.Size
$form.StartPosition='CenterScreen'; $form.BackColor=$bg
$form.FormBorderStyle='FixedDialog'; $form.MaximizeBox=$false
try { $form.Icon=[System.Drawing.Icon]::new((Join-Path $source 'mindspark_bot.ico')) } catch {}
$form.Controls.Add((Label 'MINDSpark' 34 28 600 31 12 $green $true))
$form.Controls.Add((Label 'Install Mindspark Bot' 34 72 610 48 24 $text $true))
$form.Controls.Add((Label 'Windows  |  Version 1.1.44' 36 124 600 26 11 $muted))
$form.Controls.Add((Label 'The setup checks Python, installs the bot, and adds desktop shortcuts.' 36 164 610 48 11 $text))

$status=Label 'Ready to install' 36 232 605 31 12 $green $true
$form.Controls.Add($status)
$progress=New-Object System.Windows.Forms.ProgressBar
$progress.Left=36;$progress.Top=270;$progress.Width=607;$progress.Height=8
$progress.Style='Continuous';$form.Controls.Add($progress)

$log=New-Object System.Windows.Forms.TextBox
$log.Left=36;$log.Top=305;$log.Width=607;$log.Height=140
$log.Multiline=$true;$log.ReadOnly=$true;$log.ScrollBars='Vertical'
$log.BackColor=$panel;$log.ForeColor=$muted
$log.Font=[System.Drawing.Font]::new('Consolas',[single]9)
$form.Controls.Add($log)

$start=New-Object System.Windows.Forms.Button
$start.Text='Install bot';$start.Left=36;$start.Top=467;$start.Width=145;$start.Height=43
$start.FlatStyle='Flat';$start.BackColor=$green;$start.ForeColor=$bg
$start.Font=[System.Drawing.Font]::new('Segoe UI',[single]10,[System.Drawing.FontStyle]::Bold)
$form.Controls.Add($start)
$close=New-Object System.Windows.Forms.Button
$close.Text='Close';$close.Left=530;$close.Top=467;$close.Width=113;$close.Height=43
$close.FlatStyle='Flat';$close.BackColor=$panel;$close.ForeColor=$text
$form.Controls.Add($close)
$close.Add_Click({$form.Close()})

$timer=New-Object System.Windows.Forms.Timer
$timer.Interval=350
$script:process=$null
$script:running=$false
$timer.Add_Tick({
    if(Test-Path $logPath) {
        try {
            $lines=@([IO.File]::ReadAllLines($logPath))
            $new=($lines | Select-Object -Last 18) -join [Environment]::NewLine
            if($log.Text -ne $new){$log.Text=$new;$log.SelectionStart=$log.TextLength;$log.ScrollToCaret()}
        } catch {}
    }
    if($script:running -and $script:process.HasExited) {
        $timer.Stop();$script:running=$false
        $progress.Style='Continuous'
        if($script:process.ExitCode -eq 0) {
            $progress.Value=100;$status.Text='Installed successfully'
            $start.Text='Open Mindspark Bot';$start.Enabled=$true
            $start.Tag='launch'
        } else {
            $status.Text='Installation needs attention'
            $status.ForeColor=[System.Drawing.Color]::FromArgb(255,100,110)
            $start.Text='Try again';$start.Enabled=$true
            $start.Tag='retry'
        }
        $script:process.Dispose()
    }
})
$start.Add_Click({
    if($start.Tag -eq 'launch') {
        $vbs=Join-Path $env:LOCALAPPDATA 'MindsparkBot\launcher\launch.vbs'
        if(Test-Path $vbs){Start-Process "$env:WINDIR\System32\wscript.exe" -ArgumentList ('"'+$vbs+'"')}
        $form.Close();return
    }
    $start.Enabled=$false
    $status.Text='Installing and checking dependencies...';$status.ForeColor=$green
    $progress.Style='Marquee';$log.Text='Preparing setup...'
    Remove-Item $logPath -ErrorAction SilentlyContinue
    $psi=New-Object Diagnostics.ProcessStartInfo
    $psi.FileName="$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe"
    $psi.Arguments='-NoProfile -ExecutionPolicy Bypass -File "'+$runner+'" "'+$logPath+'"'
    $psi.UseShellExecute=$false;$psi.CreateNoWindow=$true
    try {
        $script:process=[Diagnostics.Process]::Start($psi)
        $script:running=$true;$timer.Start()
    } catch {
        $status.Text='Could not start setup: '+$_.Exception.Message
        $progress.Style='Continuous';$start.Enabled=$true
    }
})
$form.Add_FormClosing({
    param($sender,$eventArgs)
    if($script:running) {
        [System.Windows.Forms.MessageBox]::Show('Installation is still running. Wait for it to finish.','Mindspark Bot Setup') | Out-Null
        $eventArgs.Cancel=$true
    }
})
[void]$form.ShowDialog()
