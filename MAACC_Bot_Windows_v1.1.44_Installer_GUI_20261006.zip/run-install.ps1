param([Parameter(Mandatory=$true)][string]$LogPath)
$ErrorActionPreference='Stop'
try {
    & (Join-Path $PSScriptRoot 'install.ps1') *>&1 | Out-File -FilePath $LogPath -Encoding UTF8
    exit 0
} catch {
    $_ | Out-File -FilePath $LogPath -Encoding UTF8 -Append
    exit 1
}
