@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0setup-ui-windows.ps1"
