Set s=CreateObject("WScript.Shell")
Set f=CreateObject("Scripting.FileSystemObject")
p=f.GetParentFolderName(WScript.ScriptFullName) & "\setup-ui-windows.ps1"
s.Run "powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File " & Chr(34) & p & Chr(34), 0, False
