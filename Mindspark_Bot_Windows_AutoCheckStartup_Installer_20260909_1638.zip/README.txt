MINDSPARK BOT - WINDOWS (AUTOMATIC STARTUP UPDATE CHECK)

1. Extract this ZIP.
2. Double-click INSTALL_MINDSPARK_BOT.cmd.
3. Launch "Mindspark Bot" normally from Desktop or Start Menu.

EVERY NORMAL STARTUP:
- The launcher checks the owner's GitHub latest.json feed.
- If no newer version exists, the bot opens normally.
- If a newer version exists, a Yes/No prompt appears BEFORE the bot opens.
  YES = download, verify, back up old version, install update, then open the new bot.
  NO  = keep the installed version and open it normally.
- If the cloud check fails, the installed bot still opens; the error is only logged.

Cloud feed is pre-connected to:
https://raw.githubusercontent.com/Noodlee-4767/MAACC-bot-updates/main/latest.json

The separate "Mindspark Bot Updater" Start-menu shortcut remains available only
for manual .msupdate installation, cloud settings and rollback.
