#!/usr/bin/env python3
"""Graphical first-launch bootstrap for Mindspark Bot on Ubuntu.

This launcher intentionally does not alter the bundled bot payload. It prepares
per-user Python dependencies and a user-local Google Chrome fallback, then runs
the exact packaged ChromeOS/Linux bot script with the prepared interpreter.
"""
from __future__ import annotations

import os
import pathlib
import shutil
import subprocess
import sys
import tempfile
import threading
import traceback
import urllib.request

APP_NAME = "Mindspark Bot"
BASE = pathlib.Path.home() / ".local" / "share" / "mindspark-bot"
RUNTIME = BASE / "runtime-ubuntu"
VENV = RUNTIME / "venv"
CHROME_BASE = BASE / "google-chrome"
CHROME_BIN = CHROME_BASE / "opt" / "google" / "chrome" / "chrome"
LOG_DIR = BASE / "logs"
LOG_FILE = LOG_DIR / "ubuntu-launcher.log"
BOT = pathlib.Path("/opt/mindspark-bot/mindspark_bot.py")
REQUIREMENTS = pathlib.Path("/opt/mindspark-bot/requirements-ubuntu.txt")
CHROME_URL = "https://dl.google.com/linux/direct/google-chrome-stable_current_amd64.deb"


def _log(message: str) -> None:
    LOG_DIR.mkdir(parents=True, exist_ok=True)
    with LOG_FILE.open("a", encoding="utf-8") as handle:
        handle.write(message.rstrip() + "\n")


def _run(cmd, *, env=None, check=True, capture=False):
    _log("$ " + " ".join(map(str, cmd)))
    kwargs = {"env": env, "check": check, "text": True}
    if capture:
        kwargs["stdout"] = subprocess.PIPE
        kwargs["stderr"] = subprocess.STDOUT
    result = subprocess.run(list(map(str, cmd)), **kwargs)
    if capture and result.stdout:
        _log(result.stdout)
    return result


def _venv_python() -> pathlib.Path:
    return VENV / "bin" / "python3"


def _deps_ready() -> bool:
    py = _venv_python()
    if not py.exists():
        return False
    code = "import openpyxl,cv2,numpy,PIL,playwright; print('ok')"
    try:
        return _run([py, "-c", code], check=False, capture=True).returncode == 0
    except Exception:
        return False


def _ensure_python_runtime(status) -> None:
    RUNTIME.mkdir(parents=True, exist_ok=True)
    py = _venv_python()
    if not py.exists():
        status("Creating the private Python runtime…")
        _run(["/usr/bin/python3", "-m", "venv", str(VENV)])
    if not _deps_ready():
        status("Installing bot components…")
        env = os.environ.copy()
        env["PIP_DISABLE_PIP_VERSION_CHECK"] = "1"
        env["PIP_NO_INPUT"] = "1"
        _run([py, "-m", "pip", "install", "--upgrade", "pip", "setuptools", "wheel"], env=env)
        _run([py, "-m", "pip", "install", "-r", REQUIREMENTS], env=env)
    if not _deps_ready():
        raise RuntimeError("Python components could not be prepared.")


def _system_chrome() -> str | None:
    candidates = [
        "/usr/bin/google-chrome-stable",
        "/usr/bin/google-chrome",
        str(CHROME_BIN),
    ]
    for item in candidates:
        if os.path.isfile(item) and os.access(item, os.X_OK):
            return item
    return shutil.which("google-chrome-stable") or shutil.which("google-chrome")


def _ensure_google_chrome(status) -> None:
    if _system_chrome():
        return
    if os.uname().machine not in ("x86_64", "amd64"):
        raise RuntimeError("This Ubuntu installer requires an amd64/x86_64 system for Google Chrome.")
    if shutil.which("dpkg-deb") is None:
        raise RuntimeError("dpkg-deb is missing. Reinstall the Ubuntu package tools and try again.")

    status("Downloading Google Chrome…")
    CHROME_BASE.mkdir(parents=True, exist_ok=True)
    fd, temp_name = tempfile.mkstemp(prefix="mindspark-chrome-", suffix=".deb", dir=str(RUNTIME))
    os.close(fd)
    temp = pathlib.Path(temp_name)
    try:
        req = urllib.request.Request(CHROME_URL, headers={"User-Agent": "MindsparkBot-Ubuntu/1.1.25"})
        with urllib.request.urlopen(req, timeout=90) as response, temp.open("wb") as out:
            shutil.copyfileobj(response, out)
        if temp.stat().st_size < 20_000_000:
            raise RuntimeError("Google Chrome download was incomplete.")

        status("Preparing Google Chrome…")
        # Replace only the user-local Chrome directory used by this app.
        if CHROME_BASE.exists():
            for child in CHROME_BASE.iterdir():
                if child.name != temp.name:
                    if child.is_dir():
                        shutil.rmtree(child, ignore_errors=True)
                    else:
                        try:
                            child.unlink()
                        except OSError:
                            pass
        _run(["dpkg-deb", "-x", temp, CHROME_BASE])
        if not CHROME_BIN.exists():
            raise RuntimeError("Google Chrome was downloaded but could not be prepared.")
        CHROME_BIN.chmod(CHROME_BIN.stat().st_mode | 0o111)
    finally:
        try:
            temp.unlink()
        except OSError:
            pass

    if not _system_chrome():
        raise RuntimeError("Google Chrome setup did not complete.")


def _launch_bot() -> None:
    py = _venv_python()
    env = os.environ.copy()
    env.setdefault("HOME", str(pathlib.Path.home()))
    env["PATH"] = "/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:" + env.get("PATH", "")
    env.setdefault("XDG_DATA_HOME", str(pathlib.Path.home() / ".local" / "share"))
    env.setdefault("XDG_CACHE_HOME", str(pathlib.Path.home() / ".cache"))
    env.setdefault("PLAYWRIGHT_BROWSERS_PATH", str(pathlib.Path.home() / ".cache" / "ms-playwright"))
    _log(f"Launching exact bot payload: {BOT}")
    os.execve(str(py), [str(py), str(BOT)], env)


def _graphical_main() -> int:
    # Tk is deliberately imported here so installation errors can still be logged.
    import tkinter as tk
    from tkinter import messagebox

    root = tk.Tk()
    root.title(APP_NAME + " Setup")
    root.geometry("460x190")
    root.resizable(False, False)

    title = tk.Label(root, text="Mindspark Bot", font=("Sans", 18, "bold"))
    title.pack(pady=(22, 6))
    detail_var = tk.StringVar(value="Checking Ubuntu setup…")
    detail = tk.Label(root, textvariable=detail_var, font=("Sans", 10), wraplength=410, justify="center")
    detail.pack(pady=(0, 12))
    pulse = tk.Label(root, text="First launch can take a little longer while components are prepared.", font=("Sans", 9))
    pulse.pack()

    def status(text: str) -> None:
        _log(text)
        root.after(0, detail_var.set, text)

    result = {"error": None}

    def worker():
        try:
            LOG_DIR.mkdir(parents=True, exist_ok=True)
            _log("\n=== Ubuntu launcher start ===")
            _ensure_python_runtime(status)
            _ensure_google_chrome(status)
            status("Starting Mindspark Bot…")
        except Exception as exc:
            result["error"] = exc
            _log(traceback.format_exc())
        finally:
            root.after(0, root.quit)

    threading.Thread(target=worker, daemon=True).start()
    root.mainloop()

    if result["error"] is not None:
        messagebox.showerror(
            "Mindspark Bot Setup",
            "Setup could not finish.\n\n"
            + str(result["error"])
            + "\n\nLog: " + str(LOG_FILE),
        )
        root.destroy()
        return 1

    root.destroy()
    _launch_bot()
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(_graphical_main())
    except Exception as exc:
        try:
            _log(traceback.format_exc())
        except Exception:
            pass
        # Last-resort graphical error for launcher-level failures.
        try:
            import tkinter as tk
            from tkinter import messagebox
            r = tk.Tk(); r.withdraw()
            messagebox.showerror("Mindspark Bot", f"Could not start Mindspark Bot.\n\n{exc}\n\nLog: {LOG_FILE}")
            r.destroy()
        except Exception:
            pass
        raise
