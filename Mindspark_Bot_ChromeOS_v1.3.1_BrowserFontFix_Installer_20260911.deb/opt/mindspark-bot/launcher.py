#!/usr/bin/env python3
"""Mindspark Bot permanent launcher/updater for Windows and ChromeOS Linux.

Normal bot releases live in a writable per-user 'current' directory.  The
launcher can install a universal .msupdate file manually, or fetch one from a
cloud latest.json manifest.  Before replacing a release it makes a complete
backup, validates hashes and Python syntax, and supports rollback.
"""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import platform
import queue
import shutil
import subprocess
import sys
import tempfile
import threading
import time
import traceback
import tkinter as tk
from tkinter import filedialog, messagebox, simpledialog
import urllib.parse
import urllib.request
import zipfile

LAUNCHER_VERSION = '1.3.1'
RUNTIME_VERSION = 'playwright-1.57.0-googlechrome-r2'
PLAYWRIGHT_REQUIREMENT = 'playwright==1.57.0'
DEFAULT_PIP_REQUIREMENTS = [PLAYWRIGHT_REQUIREMENT, 'openpyxl>=3.0', 'pillow>=9.0']
CHECK_INTERVAL_SECONDS = 60 * 60  # retained for updater-window caching; normal startup forces a fresh check
SCRIPT_DIR = Path(__file__).resolve().parent
SEED_PACKAGE = SCRIPT_DIR / 'seed_update.msupdate'
DEFAULT_MANIFEST_URL = 'https://raw.githubusercontent.com/Noodlee-4767/MAACC-bot-updates/main/latest.json'
PACKAGE_VERSION = '1.3.1-20260911'


def prepare_process_environment() -> None:
    """Normalize only the small set of values a GUI launch may lack.

    ChromeOS/Crostini normally supplies DISPLAY/Wayland values itself.  We keep
    any values it provides and only recover conservative defaults when they are
    absent and the corresponding socket/directory actually exists.
    """
    home_text = os.environ.get('HOME', '').strip()
    if not home_text:
        try:
            home_text = str(Path('~').expanduser())
        except Exception:
            home_text = ''
        if home_text and home_text != '~':
            os.environ['HOME'] = home_text
    home = Path(home_text) if home_text else Path.home()

    current_path = os.environ.get('PATH', '')
    default_parts = ['/usr/local/bin', '/usr/bin', '/bin']
    path_parts = [p for p in current_path.split(os.pathsep) if p]
    for item in default_parts:
        if item not in path_parts:
            path_parts.append(item)
    os.environ['PATH'] = os.pathsep.join(path_parts)

    os.environ.setdefault('XDG_DATA_HOME', str(home / '.local' / 'share'))
    os.environ.setdefault('XDG_CONFIG_HOME', str(home / '.config'))
    os.environ.setdefault('XDG_CACHE_HOME', str(home / '.cache'))
    os.environ.setdefault('XDG_STATE_HOME', str(home / '.local' / 'state'))
    os.environ.setdefault(
        'PLAYWRIGHT_BROWSERS_PATH',
        str(Path(os.environ['XDG_CACHE_HOME']) / 'mindspark-bot' / 'ms-playwright'))

    if platform.system() == 'Linux':
        try:
            uid = os.getuid()
        except AttributeError:
            uid = None
        if uid is not None and not os.environ.get('XDG_RUNTIME_DIR'):
            runtime_dir = Path('/run/user') / str(uid)
            if runtime_dir.is_dir():
                os.environ['XDG_RUNTIME_DIR'] = str(runtime_dir)
        if not os.environ.get('DISPLAY') and Path('/tmp/.X11-unix/X0').exists():
            os.environ['DISPLAY'] = ':0'
        runtime_text = os.environ.get('XDG_RUNTIME_DIR', '')
        if not os.environ.get('WAYLAND_DISPLAY') and runtime_text:
            if (Path(runtime_text) / 'wayland-0').exists():
                os.environ['WAYLAND_DISPLAY'] = 'wayland-0'

    try:
        os.chdir(home)
    except Exception:
        pass


prepare_process_environment()
SYSTEM = platform.system()
if SYSTEM == 'Windows':
    PLATFORM_KEY = 'windows'
    BASE = Path(os.environ.get('LOCALAPPDATA') or (Path.home() / 'AppData' / 'Local')) / 'MindsparkBot'
else:
    PLATFORM_KEY = 'chromeos'
    BASE = Path.home() / '.local' / 'share' / 'mindspark-bot'

CURRENT = BASE / 'current'
BACKUPS = BASE / 'backups'
RUNTIME = BASE / 'runtime'
STATE_DIR = BASE / 'state'
LOG_DIR = BASE / 'logs'
CONFIG_FILE = BASE / 'update_config.json'
STATE_FILE = STATE_DIR / 'launcher_state.json'
RUN_LOCK = STATE_DIR / 'bot.lock'
LOG_FILE = LOG_DIR / 'launcher.log'
CHROME_ROOT = BASE / 'google-chrome'
CHROME_BINARY = CHROME_ROOT / 'opt' / 'google' / 'chrome' / 'chrome'
CHROME_MARKER = CHROME_ROOT / '.mindspark-google-chrome-version'
CHROME_DOWNLOAD_URL = 'https://dl.google.com/linux/direct/google-chrome-stable_current_amd64.deb'


def log(message: str) -> None:
    try:
        LOG_DIR.mkdir(parents=True, exist_ok=True)
        with LOG_FILE.open('a', encoding='utf-8') as f:
            f.write(f"[{time.strftime('%Y-%m-%d %H:%M:%S')}] {message.rstrip()}\n")
    except Exception:
        pass


SAFE_ENV_KEYS = (
    'HOME', 'PATH', 'DISPLAY', 'WAYLAND_DISPLAY', 'XDG_RUNTIME_DIR',
    'XDG_DATA_HOME', 'XDG_CONFIG_HOME', 'XDG_CACHE_HOME', 'XDG_STATE_HOME',
    'XDG_CURRENT_DESKTOP', 'DESKTOP_STARTUP_ID', 'PLAYWRIGHT_BROWSERS_PATH',
)


def log_startup_context(mode: str) -> None:
    try:
        log(f'=== START mode={mode} package={PACKAGE_VERSION} launcher={LAUNCHER_VERSION} ===')
        log(f'platform={SYSTEM} python={sys.executable} python_version={platform.python_version()}')
        log(f'uid={getattr(os, "getuid", lambda: "n/a")()} gid={getattr(os, "getgid", lambda: "n/a")()} cwd={os.getcwd()}')
        for key in SAFE_ENV_KEYS:
            value = os.environ.get(key)
            if value is not None:
                log(f'env {key}={value!r}')
    except Exception as exc:
        log(f'Could not record startup context: {exc}')


def _linux_google_chrome() -> str | None:
    """Return the Google Chrome executable used by the ChromeOS build.

    Prefer a normal system Google Chrome if the owner already installed one.
    Otherwise use the official Chrome build downloaded by our graphical
    first-launch setup into the user's Mindspark data directory.
    """
    if SYSTEM != 'Linux':
        return None
    candidates = (
        '/usr/bin/google-chrome-stable', '/usr/bin/google-chrome',
        str(CHROME_BINARY),
    )
    for candidate in candidates:
        if os.path.isfile(candidate) and os.access(candidate, os.X_OK):
            return candidate
    return shutil.which('google-chrome-stable') or shutil.which('google-chrome')


def _download_file(url: str, target: Path, progress=lambda message: None) -> None:
    """Download a file with a small progress callback and no shell tools."""
    request = urllib.request.Request(url, headers={'User-Agent': 'MindsparkBot-ChromeOS/1.3'})
    with urllib.request.urlopen(request, timeout=60) as response, target.open('wb') as out:
        total = int(response.headers.get('Content-Length') or 0)
        done = 0
        while True:
            chunk = response.read(1024 * 1024)
            if not chunk:
                break
            out.write(chunk)
            done += len(chunk)
            if total:
                progress(f'Downloading Google Chrome… {done * 100 // total}%')
            else:
                progress(f'Downloading Google Chrome… {done // (1024 * 1024)} MB')


def ensure_google_chrome(progress=lambda message: None) -> str:
    """Ensure real Google Chrome is available for Playwright on Crostini.

    We do not install a second Debian package with sudo.  Instead, first launch
    downloads Google's official amd64 .deb and extracts its application files
    into the normal user's Mindspark data directory.  This keeps setup GUI-only
    and avoids relying on Chromium.
    """
    existing = _linux_google_chrome()
    if existing:
        log(f'Google Chrome already available: {existing}')
        return existing

    if platform.machine().lower() not in ('x86_64', 'amd64'):
        raise RuntimeError('This Chromebook build currently requires an amd64/x86_64 Linux environment for Google Chrome.')

    dpkg_deb = shutil.which('dpkg-deb') or '/usr/bin/dpkg-deb'
    if not os.path.isfile(dpkg_deb):
        raise RuntimeError('dpkg-deb is missing from the Chromebook Linux environment.')

    BASE.mkdir(parents=True, exist_ok=True)
    fd, temp_name = tempfile.mkstemp(prefix='mindspark-google-chrome-', suffix='.deb', dir=str(BASE))
    os.close(fd)
    package = Path(temp_name)
    staging = BASE / f'.google-chrome-staging-{os.getpid()}'
    try:
        package.unlink(missing_ok=True)
        progress('Downloading official Google Chrome for Linux…')
        _download_file(CHROME_DOWNLOAD_URL, package, progress)
        if package.stat().st_size < 20 * 1024 * 1024:
            raise RuntimeError('The Google Chrome download appears incomplete.')

        progress('Preparing Google Chrome…')
        shutil.rmtree(staging, ignore_errors=True)
        staging.mkdir(parents=True, exist_ok=True)
        r = subprocess.run(
            [dpkg_deb, '-x', str(package), str(staging)],
            stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
        log(r.stdout or '')
        extracted = staging / 'opt' / 'google' / 'chrome' / 'chrome'
        if r.returncode != 0 or not extracted.exists():
            raise RuntimeError('Google Chrome could not be unpacked for the bot.')

        version = 'unknown'
        try:
            info = subprocess.run(
                [dpkg_deb, '-f', str(package), 'Version'],
                stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, timeout=10)
            if info.returncode == 0 and info.stdout.strip():
                version = info.stdout.strip().splitlines()[-1]
        except Exception:
            pass

        old = CHROME_ROOT.with_name(CHROME_ROOT.name + '.old')
        shutil.rmtree(old, ignore_errors=True)
        if CHROME_ROOT.exists():
            os.replace(CHROME_ROOT, old)
        os.replace(staging, CHROME_ROOT)
        shutil.rmtree(old, ignore_errors=True)
        try:
            CHROME_BINARY.chmod(CHROME_BINARY.stat().st_mode | 0o111)
        except Exception:
            pass
        CHROME_MARKER.write_text(version, encoding='utf-8')
        log(f'Prepared Google Chrome {version} at {CHROME_BINARY}')
        progress('Google Chrome ready.')
        return str(CHROME_BINARY)
    finally:
        package.unlink(missing_ok=True)
        shutil.rmtree(staging, ignore_errors=True)


def show_error(title: str, message: str) -> None:
    """Show a GUI error when possible, with a desktop notification fallback."""
    try:
        root = tk.Tk(className='MindsparkBotError')
        root.withdraw()
        messagebox.showerror(title, message, parent=root)
        root.destroy()
        return
    except Exception as exc:
        log(f'Could not show Tk error dialog: {exc}')
    notifier = shutil.which('notify-send')
    if notifier:
        try:
            subprocess.run([notifier, title, message], timeout=5, check=False)
        except Exception as exc:
            log(f'Could not show desktop notification: {exc}')


def load_json(path: Path, default):
    try:
        return json.loads(path.read_text(encoding='utf-8'))
    except Exception:
        return default


def save_json(path: Path, value) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + '.tmp')
    temp.write_text(json.dumps(value, indent=2, ensure_ascii=False), encoding='utf-8')
    os.replace(temp, path)


def config() -> dict:
    data = load_json(CONFIG_FILE, {})
    if not isinstance(data, dict):
        data = {}
    data.setdefault('manifest_url', DEFAULT_MANIFEST_URL)
    data.setdefault('auto_check', True)
    return data


def set_config(data: dict) -> None:
    save_json(CONFIG_FILE, data)


def installed_metadata() -> dict:
    return load_json(CURRENT / 'installed.json', {})


def installed_version() -> str:
    return str(installed_metadata().get('version') or '0.0.0')


def version_key(text: str):
    # Tolerant numeric comparison: 1.2.10 > 1.2.9. Non-numeric suffixes are
    # ignored for ordering but kept in display strings.
    parts = []
    for piece in str(text).split('.'):
        digits = ''.join(ch for ch in piece if ch.isdigit())
        parts.append(int(digits or 0))
    while len(parts) < 4:
        parts.append(0)
    return tuple(parts[:4])


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def safe_relative(path_text: str) -> Path:
    p = Path(path_text)
    if p.is_absolute() or '..' in p.parts:
        raise RuntimeError(f'Unsafe update path: {path_text}')
    return p


def _venv_python(console: bool = True) -> Path:
    if SYSTEM == 'Windows':
        if not console and (RUNTIME / 'Scripts' / 'pythonw.exe').exists():
            return RUNTIME / 'Scripts' / 'pythonw.exe'
        return RUNTIME / 'Scripts' / 'python.exe'
    return RUNTIME / 'bin' / 'python'


def _venv_pip() -> Path:
    if SYSTEM == 'Windows':
        return RUNTIME / 'Scripts' / 'pip.exe'
    return RUNTIME / 'bin' / 'pip'


def runtime_ok() -> bool:
    py = _venv_python()
    marker = RUNTIME / '.mindspark-runtime-version'
    if not py.exists() or not marker.exists():
        return False
    try:
        if marker.read_text(encoding='utf-8').strip() != RUNTIME_VERSION:
            return False
        r = subprocess.run(
            [str(py), '-c', 'import playwright, openpyxl; from PIL import Image'],
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=20)
        if r.returncode != 0:
            return False
        if SYSTEM == 'Linux' and not _linux_google_chrome():
            return False
        return True
    except Exception:
        return False


def prepare_runtime(progress=lambda message: None, requirements=None) -> None:
    requirements = requirements or DEFAULT_PIP_REQUIREMENTS
    BASE.mkdir(parents=True, exist_ok=True)
    if RUNTIME.exists() and not _venv_python().exists():
        shutil.rmtree(RUNTIME, ignore_errors=True)
    if not _venv_python().exists():
        progress('Creating private bot runtime…')
        cmd = [sys.executable, '-m', 'venv']
        if SYSTEM != 'Windows':
            cmd.append('--system-site-packages')
        cmd.append(str(RUNTIME))
        r = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
        log(r.stdout or '')
        if r.returncode != 0:
            raise RuntimeError('Could not create the private bot runtime.')

    progress('Preparing browser automation components…')
    pip = _venv_pip()
    r = subprocess.run(
        [str(pip), 'install', '--disable-pip-version-check', '--no-input', '--no-cache-dir', '--upgrade', *requirements],
        stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    log(r.stdout or '')
    if r.returncode != 0:
        raise RuntimeError('Could not install/update the bot runtime components. Check internet access.')

    py = _venv_python()
    r = subprocess.run(
        [str(py), '-c', 'import playwright, openpyxl; from PIL import Image; print("ok")'],
        stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    log(r.stdout or '')
    if r.returncode != 0:
        raise RuntimeError('The bot runtime failed its self-check.')

    if SYSTEM != 'Windows':
        progress('Checking Google Chrome…')
        browser = ensure_google_chrome(progress)
        log(f'Using Google Chrome: {browser}')

    (RUNTIME / '.mindspark-runtime-version').write_text(RUNTIME_VERSION, encoding='utf-8')
    progress('Runtime ready.')


def pid_alive(pid: int) -> bool:
    try:
        os.kill(int(pid), 0)
        return True
    except Exception:
        return False


def bot_is_running() -> bool:
    info = load_json(RUN_LOCK, {})
    pid = info.get('pid') if isinstance(info, dict) else None
    if pid and pid_alive(pid):
        return True
    try:
        RUN_LOCK.unlink(missing_ok=True)
    except Exception:
        pass
    return False


def _read_update_manifest(z: zipfile.ZipFile) -> dict:
    try:
        data = json.loads(z.read('manifest.json').decode('utf-8'))
    except Exception as exc:
        raise RuntimeError(f'Invalid update package manifest: {exc}')
    if data.get('format') != 1 or not data.get('version'):
        raise RuntimeError('Unsupported or incomplete update package.')
    if PLATFORM_KEY not in (data.get('platforms') or {}):
        raise RuntimeError(f'This update does not contain a {PLATFORM_KEY} build.')
    return data


def inspect_package(package_path: Path) -> dict:
    with zipfile.ZipFile(package_path, 'r') as z:
        return _read_update_manifest(z)


def install_package(package_path: Path, expected_sha256: str | None = None, allow_same=True,
                    progress=lambda message: None) -> dict:
    if bot_is_running():
        raise RuntimeError('Close Mindspark Bot before installing or restoring an update.')
    package_path = Path(package_path)
    if not package_path.exists():
        raise RuntimeError('Update package not found.')
    if expected_sha256:
        progress('Verifying downloaded update…')
        actual = sha256_file(package_path)
        if actual.lower() != expected_sha256.lower():
            raise RuntimeError('Update verification failed (SHA-256 mismatch). Nothing was changed.')

    with zipfile.ZipFile(package_path, 'r') as z:
        manifest = _read_update_manifest(z)
        new_version = str(manifest['version'])
        if not allow_same and version_key(new_version) <= version_key(installed_version()):
            return manifest
        platform_info = manifest['platforms'][PLATFORM_KEY]
        files = platform_info.get('files') or []
        if not files:
            raise RuntimeError('Update package contains no application files.')

        BASE.mkdir(parents=True, exist_ok=True)
        BACKUPS.mkdir(parents=True, exist_ok=True)
        staging = BASE / f'.staging-{os.getpid()}-{int(time.time())}'
        shutil.rmtree(staging, ignore_errors=True)
        staging.mkdir(parents=True)
        try:
            progress(f'Preparing Mindspark Bot {new_version}…')
            for item in files:
                archive_path = str(item['archive_path'])
                install_path = safe_relative(str(item['install_path']))
                data = z.read(archive_path)
                expected = str(item.get('sha256') or '')
                actual = hashlib.sha256(data).hexdigest()
                if expected and expected.lower() != actual.lower():
                    raise RuntimeError(f'File verification failed: {install_path}')
                if install_path.suffix.lower() == '.py':
                    try:
                        compile(data.decode('utf-8'), str(install_path), 'exec')
                    except Exception as exc:
                        raise RuntimeError(f'Python validation failed for {install_path}: {exc}')
                dest = staging / install_path
                dest.parent.mkdir(parents=True, exist_ok=True)
                dest.write_bytes(data)

            entrypoint = safe_relative(str(platform_info.get('entrypoint') or 'mindspark_bot.py'))
            if not (staging / entrypoint).exists():
                raise RuntimeError('Update entrypoint is missing.')
            save_json(staging / 'installed.json', {
                'version': new_version,
                'notes': manifest.get('notes', ''),
                'installed_at': time.strftime('%Y-%m-%dT%H:%M:%S'),
                'platform': PLATFORM_KEY,
                'entrypoint': str(entrypoint),
            })

            old_backup = None
            if CURRENT.exists():
                old_version = installed_version().replace('/', '_').replace('\\', '_')
                old_backup = BACKUPS / f'{old_version}-{time.strftime("%Y%m%d-%H%M%S")}'
                progress('Backing up the current version…')
                os.replace(CURRENT, old_backup)
            try:
                os.replace(staging, CURRENT)
            except Exception:
                if old_backup and old_backup.exists() and not CURRENT.exists():
                    os.replace(old_backup, CURRENT)
                raise
        finally:
            shutil.rmtree(staging, ignore_errors=True)

    reqs = manifest.get('pip_requirements') or []
    if reqs and runtime_ok():
        progress('Checking update dependencies…')
        pip = _venv_pip()
        r = subprocess.run(
            [str(pip), 'install', '--disable-pip-version-check', '--no-input', '--no-cache-dir', '--upgrade', *reqs],
            stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
        log(r.stdout or '')
        if r.returncode != 0:
            log('Dependency update warning: pip returned non-zero; app payload was installed.')

    log(f'Installed update {new_version} for {PLATFORM_KEY}')
    return manifest


def ensure_seed_installed(progress=lambda message: None) -> None:
    """Install the packaged seed when missing or newer than current.

    This matters for .deb upgrades: packaging fixes that include a newer
    ChromeOS payload must replace an older per-user current build, while a
    user who already has a newer cloud build must never be downgraded.
    """
    if not SEED_PACKAGE.exists():
        raise RuntimeError('The installer seed package is missing.')
    seed = inspect_package(SEED_PACKAGE)
    seed_version = str(seed.get('version') or '0.0.0')
    current_ready = (CURRENT / 'installed.json').exists() and (CURRENT / 'mindspark_bot.py').exists()
    if current_ready and version_key(installed_version()) >= version_key(seed_version):
        return
    progress(f'Installing packaged Mindspark Bot {seed_version}…')
    install_package(SEED_PACKAGE, allow_same=True, progress=progress)


def backups() -> list[Path]:
    if not BACKUPS.exists():
        return []
    return sorted([p for p in BACKUPS.iterdir() if p.is_dir() and (p / 'installed.json').exists()],
                  key=lambda p: p.stat().st_mtime, reverse=True)


def rollback_latest(progress=lambda message: None) -> str:
    if bot_is_running():
        raise RuntimeError('Close Mindspark Bot before restoring a previous version.')
    choices = backups()
    if not choices:
        raise RuntimeError('No previous version backup is available yet.')
    previous = choices[0]
    previous_meta = load_json(previous / 'installed.json', {})
    previous_version = str(previous_meta.get('version') or previous.name)
    BACKUPS.mkdir(parents=True, exist_ok=True)
    current_backup = BACKUPS / f'rollback-from-{installed_version()}-{time.strftime("%Y%m%d-%H%M%S")}'
    progress(f'Restoring {previous_version}…')
    if CURRENT.exists():
        os.replace(CURRENT, current_backup)
    try:
        os.replace(previous, CURRENT)
    except Exception:
        if current_backup.exists() and not CURRENT.exists():
            os.replace(current_backup, CURRENT)
        raise
    log(f'Rolled back to {previous_version}')
    return previous_version


def fetch_json(url: str, timeout=6) -> dict:
    req = urllib.request.Request(url, headers={'User-Agent': 'MindsparkBotUpdater/1.0'})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        raw = r.read(1024 * 1024)
    data = json.loads(raw.decode('utf-8'))
    if not isinstance(data, dict):
        raise RuntimeError('Cloud manifest is not a JSON object.')
    return data


def cloud_latest(force=False) -> dict | None:
    cfg = config()
    url = str(cfg.get('manifest_url') or '').strip()
    if not url:
        return None
    state = load_json(STATE_FILE, {})
    now = time.time()
    if not force and now - float(state.get('last_cloud_check', 0) or 0) < CHECK_INTERVAL_SECONDS:
        cached = state.get('cached_latest')
        return cached if isinstance(cached, dict) else None
    data = fetch_json(url)
    if data.get('format') != 1 or not data.get('version') or not data.get('package_url'):
        raise RuntimeError('Cloud latest.json is incomplete.')
    data['_manifest_url'] = url
    state['last_cloud_check'] = now
    state['cached_latest'] = data
    save_json(STATE_FILE, state)
    return data


def download_cloud_package(latest: dict, progress=lambda message: None) -> Path:
    manifest_url = latest.get('_manifest_url') or config().get('manifest_url') or ''
    package_url = urllib.parse.urljoin(manifest_url, str(latest['package_url']))
    progress('Downloading update…')
    req = urllib.request.Request(package_url, headers={'User-Agent': 'MindsparkBotUpdater/1.0'})
    fd, name = tempfile.mkstemp(prefix='mindspark-update-', suffix='.msupdate')
    os.close(fd)
    path = Path(name)
    try:
        with urllib.request.urlopen(req, timeout=30) as r, path.open('wb') as f:
            shutil.copyfileobj(r, f)
        expected = str(latest.get('sha256') or '')
        if expected and sha256_file(path).lower() != expected.lower():
            raise RuntimeError('Downloaded update failed SHA-256 verification.')
        return path
    except Exception:
        path.unlink(missing_ok=True)
        raise


def _progress_window(title: str, worker):
    root = tk.Tk(className='MindsparkBotSetup')
    root.title(title)
    root.geometry('520x185')
    root.resizable(False, False)
    tk.Label(root, text=title, font=('TkDefaultFont', 15, 'bold')).pack(pady=(25, 10))
    status = tk.StringVar(value='Starting…')
    tk.Label(root, textvariable=status, wraplength=465, justify='center').pack(pady=8)
    result = {'value': None, 'error': None}
    events = queue.Queue()

    def progress(message):
        events.put(('progress', str(message)))

    def run():
        try:
            value = worker(progress)
            events.put(('done', value))
        except Exception as exc:
            log('Worker traceback:\n' + traceback.format_exc())
            events.put(('error', exc))

    def poll_events():
        finished = False
        while True:
            try:
                kind, value = events.get_nowait()
            except queue.Empty:
                break
            if kind == 'progress':
                status.set(value)
            elif kind == 'done':
                result['value'] = value
                finished = True
            elif kind == 'error':
                result['error'] = value
                finished = True
        if finished:
            root.after(25, root.destroy)
        else:
            root.after(80, poll_events)

    threading.Thread(target=run, daemon=True).start()
    root.after(50, poll_events)
    root.mainloop()
    if result['error']:
        raise result['error']
    return result['value']


def ensure_ready_with_ui() -> None:
    if not (CURRENT / 'mindspark_bot.py').exists():
        _progress_window('Preparing Mindspark Bot', lambda p: ensure_seed_installed(p))
    if not runtime_ok():
        _progress_window('Mindspark Bot — First Launch Setup', lambda p: prepare_runtime(p))


def launch_current_bot() -> int:
    ensure_ready_with_ui()
    meta = installed_metadata()
    entrypoint = safe_relative(str(meta.get('entrypoint') or 'mindspark_bot.py'))
    bot_script = CURRENT / entrypoint
    if not bot_script.exists():
        raise RuntimeError('The current bot program is missing.')
    if bot_is_running():
        messagebox.showinfo('Mindspark Bot', 'Mindspark Bot is already running.')
        return 0

    cfg = config()
    if cfg.get('auto_check', True) and cfg.get('manifest_url'):
        try:
            # Every normal app launch checks the owner's cloud feed freshly.
            # If a newer release exists, ask before the bot opens. Choosing No
            # keeps the installed version and launches it normally.
            latest = cloud_latest(force=True)
            if latest and version_key(str(latest['version'])) > version_key(installed_version()):
                notes = str(latest.get('notes') or '').strip()
                text = f"Mindspark Bot {latest['version']} is available.\n\n{notes}\n\nInstall it now?"
                if messagebox.askyesno('Mindspark Bot Update', text):
                    def do_update(progress):
                        package = download_cloud_package(latest, progress)
                        try:
                            return install_package(package, str(latest.get('sha256') or ''), progress=progress)
                        finally:
                            package.unlink(missing_ok=True)
                    _progress_window('Updating Mindspark Bot', do_update)
        except Exception as exc:
            log(f'Automatic cloud check skipped: {exc}')

    py = _venv_python(console=False)
    RUN_LOCK.parent.mkdir(parents=True, exist_ok=True)
    LOG_DIR.mkdir(parents=True, exist_ok=True)
    process_log = LOG_DIR / 'bot-process.log'
    child_env = os.environ.copy()
    child_env['PYTHONUNBUFFERED'] = '1'
    started = time.time()
    with process_log.open('a', encoding='utf-8') as stream:
        stream.write(f"\n[{time.strftime('%Y-%m-%d %H:%M:%S')}] Starting Mindspark Bot {installed_version()} via {py}\n")
        stream.flush()
        proc = subprocess.Popen(
            [str(py), str(bot_script)], cwd=str(Path.home()), env=child_env,
            stdout=stream, stderr=subprocess.STDOUT)
        save_json(RUN_LOCK, {'pid': proc.pid, 'started': started, 'version': installed_version()})
        try:
            rc = proc.wait()
            elapsed = time.time() - started
            log(f'Bot process exited rc={rc} after {elapsed:.1f}s')
            if rc != 0:
                raise RuntimeError(
                    f'Mindspark Bot exited unexpectedly (code {rc}).\n\n'
                    f'Diagnostics were saved automatically to:\n{process_log}')
            return 0
        finally:
            try:
                info = load_json(RUN_LOCK, {})
                if info.get('pid') == proc.pid:
                    RUN_LOCK.unlink(missing_ok=True)
            except Exception:
                pass


def updater_window() -> None:
    try:
        ensure_seed_installed()
    except Exception as exc:
        show_error('Mindspark Bot Updater', str(exc))
        return

    root = tk.Tk()
    root.title('Mindspark Bot Updater')
    root.geometry('610x480')
    root.resizable(False, False)

    tk.Label(root, text='Mindspark Bot Updater', font=('TkDefaultFont', 18, 'bold')).pack(pady=(22, 5))
    version_var = tk.StringVar()
    cloud_var = tk.StringVar()
    status_var = tk.StringVar(value='Ready')

    def refresh():
        version_var.set(f'Installed version: {installed_version()}    •    Updater: {LAUNCHER_VERSION}')
        url = str(config().get('manifest_url') or '').strip()
        cloud_var.set('Cloud updates: Connected' if url else 'Cloud updates: Not connected yet')

    tk.Label(root, textvariable=version_var).pack(pady=3)
    tk.Label(root, textvariable=cloud_var).pack(pady=3)
    tk.Label(root, textvariable=status_var, wraplength=540, justify='center').pack(pady=(8, 14))

    body = tk.Frame(root)
    body.pack(fill='x', padx=85)

    def run_action(title, func, success=None):
        try:
            value = _progress_window(title, func)
            refresh()
            if success:
                messagebox.showinfo('Mindspark Bot Updater', success(value), parent=root)
        except Exception as exc:
            messagebox.showerror('Mindspark Bot Updater', str(exc), parent=root)

    def check_cloud():
        url = str(config().get('manifest_url') or '').strip()
        if not url:
            messagebox.showinfo(
                'Cloud updates not connected',
                'Set the cloud latest.json URL first. Manual .msupdate files already work.', parent=root)
            return
        try:
            latest = cloud_latest(force=True)
            if version_key(str(latest['version'])) <= version_key(installed_version()):
                status_var.set(f"Up to date — {installed_version()} is the newest version.")
                return
            notes = str(latest.get('notes') or '')
            if messagebox.askyesno(
                'Update available',
                f"Version {latest['version']} is available.\n\n{notes}\n\nDownload and install?", parent=root):
                def worker(progress):
                    package = download_cloud_package(latest, progress)
                    try:
                        return install_package(package, str(latest.get('sha256') or ''), progress=progress)
                    finally:
                        package.unlink(missing_ok=True)
                run_action('Updating Mindspark Bot', worker,
                           lambda m: f"Updated successfully to {m['version']}.")
        except Exception as exc:
            messagebox.showerror('Cloud update check failed', str(exc), parent=root)

    def install_manual():
        filename = filedialog.askopenfilename(
            parent=root, title='Choose Mindspark update package',
            filetypes=[('Mindspark update', '*.msupdate'), ('ZIP package', '*.zip'), ('All files', '*.*')])
        if not filename:
            return
        path = Path(filename)
        try:
            meta = inspect_package(path)
        except Exception as exc:
            messagebox.showerror('Invalid update', str(exc), parent=root)
            return
        if not messagebox.askyesno(
            'Install update',
            f"Install Mindspark Bot {meta['version']}?\n\n{meta.get('notes','')}", parent=root):
            return
        run_action('Installing Mindspark Update', lambda p: install_package(path, progress=p),
                   lambda m: f"Installed version {m['version']} successfully.\nA backup of the previous version was kept.")

    def restore():
        choices = backups()
        if not choices:
            messagebox.showinfo('Restore', 'No previous-version backup exists yet.', parent=root)
            return
        meta = load_json(choices[0] / 'installed.json', {})
        v = meta.get('version') or choices[0].name
        if not messagebox.askyesno('Restore previous version', f'Restore the latest backup ({v})?', parent=root):
            return
        run_action('Restoring Mindspark Bot', lambda p: rollback_latest(p),
                   lambda version: f'Restored Mindspark Bot {version}.')

    def set_cloud():
        cfg = config()
        current = str(cfg.get('manifest_url') or '')
        value = simpledialog.askstring(
            'Cloud update source',
            'Paste the HTTPS URL of Mindspark latest.json.\n\nLeave blank to disable cloud updates.',
            initialvalue=current, parent=root)
        if value is None:
            return
        value = value.strip()
        if value and not (value.startswith('https://') or value.startswith('http://') or value.startswith('file://')):
            messagebox.showerror('Invalid URL', 'Use an https:// URL (or file:// for local testing).', parent=root)
            return
        cfg['manifest_url'] = value
        set_config(cfg)
        state = load_json(STATE_FILE, {})
        state['last_cloud_check'] = 0
        save_json(STATE_FILE, state)
        refresh()
        status_var.set('Cloud update source saved.' if value else 'Cloud updates disabled; manual updates still work.')

    def launch_button():
        root.destroy()
        try:
            launch_current_bot()
        except Exception as exc:
            try:
                show_error('Mindspark Bot', str(exc))
            except Exception:
                pass

    buttons = [
        ('Open Mindspark Bot', launch_button),
        ('Check Cloud Updates', check_cloud),
        ('Install .msupdate File', install_manual),
        ('Restore Previous Version', restore),
        ('Cloud Update Settings', set_cloud),
    ]
    for text, command in buttons:
        tk.Button(body, text=text, command=command, height=2).pack(fill='x', pady=4)

    tk.Label(
        root,
        text='Normal bot updates do not reinstall the app. The updater verifies the package, backs up the current version, and swaps in the new platform build.',
        wraplength=535, justify='center').pack(pady=(14, 5))
    refresh()
    root.mainloop()


def self_test() -> dict:
    seed = inspect_package(SEED_PACKAGE)
    return {
        'package_version': PACKAGE_VERSION,
        'launcher_version': LAUNCHER_VERSION,
        'platform': SYSTEM,
        'platform_key': PLATFORM_KEY,
        'home': str(Path.home()),
        'base': str(BASE),
        'seed_version': str(seed.get('version')),
        'seed_has_platform': PLATFORM_KEY in (seed.get('platforms') or {}),
        'google_chrome': _linux_google_chrome() if SYSTEM == 'Linux' else 'n/a',
        'python': sys.executable,
    }


def main():
    BASE.mkdir(parents=True, exist_ok=True)
    mode = sys.argv[1] if len(sys.argv) > 1 else '--launch'
    log_startup_context(mode)
    try:
        if mode == '--self-test':
            print(json.dumps(self_test(), indent=2))
            return 0
        if mode == '--updater':
            updater_window()
            return 0
        if mode == '--prepare-runtime':
            prepare_runtime(lambda m: print(m, flush=True))
            return 0
        if mode == '--install-seed':
            ensure_seed_installed(lambda m: print(m, flush=True))
            return 0
        return launch_current_bot()
    except Exception as exc:
        log('Fatal launcher traceback:\n' + traceback.format_exc())
        message = f'{exc}\n\nLauncher log:\n{LOG_FILE}'
        show_error('Mindspark Bot', message)
        if not os.environ.get('DISPLAY') and not os.environ.get('WAYLAND_DISPLAY'):
            print(f'Mindspark Bot: {message}', file=sys.stderr)
        return 1


if __name__ == '__main__':
    raise SystemExit(main())
